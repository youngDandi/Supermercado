/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author santi
 */
public class Caixa {
    private int Identificador;
    private int nClientesFila;
    private int nClientesAtendidos;
    private double tempoTotalAtendimento;
    private double tempoMedioAtendimento;
    private ArrayList<Cliente> Clientes;
    
    private int ids = 1;
    Scanner ler= new Scanner(System.in);
    public int getIdentificador() {
        return Identificador;
    }

    public void setIdentificador(int Identificador) {
        this.Identificador = Identificador;
    }

    public int getnClientesFila() {
        return nClientesFila;
    }

    public void setnClientesFila(int nClientesFila) {
        this.nClientesFila = nClientesFila;
    }

    public int getnClientesAtendidos() {
        return nClientesAtendidos;
    }

    public void setnClientesAtendidos(int nClientesAtendidos) {
        this.nClientesAtendidos = nClientesAtendidos;
    }

    public double getTempoTotalAtendimento() {
        return tempoTotalAtendimento;
    }

    public void setTempoTotalAtendimento(double tempoTotalAtendimento) {
        this.tempoTotalAtendimento = tempoTotalAtendimento;
    }

    public double getTempoMedioAtendimento() {
        return tempoMedioAtendimento;
    }

    public void setTempoMedioAtendimento(double tempoMedioAtendimento) {
        this.tempoMedioAtendimento = tempoMedioAtendimento;
    }

    public ArrayList<Cliente> getClientes() {
        return Clientes;
    }

    public void setClientes(ArrayList<Cliente> Clientes) {
        this.Clientes = Clientes;
    }
    
    
    
    public Caixa(int Identificador, int nClientesFila, int nClientesAtendidos, double tempoTotalAtendimento, double tempoMedioAtendimento, ArrayList<Cliente> Clientes) {
        this.Identificador = Identificador;
        this.nClientesFila = nClientesFila;
        this.nClientesAtendidos = nClientesAtendidos;
        this.tempoTotalAtendimento = tempoTotalAtendimento;
        this.tempoMedioAtendimento = tempoMedioAtendimento;
        this.Clientes = Clientes;
    }
    
    public Caixa(int Identificador, int nClientesFila, int nClientesAtendidos, double tempoTotalAtendimento, double tempoMedioAtendimento) {
        this.Identificador = Identificador;
        this.nClientesFila = nClientesFila;
        this.nClientesAtendidos = nClientesAtendidos;
        this.tempoTotalAtendimento = tempoTotalAtendimento;
        this.tempoMedioAtendimento = tempoMedioAtendimento;
    }
   public Caixa(int Identificador,ArrayList<Cliente> Clientes) {
       this.Identificador = Identificador;
        this.Clientes = Clientes;
    }
   
    public Caixa() {
        
    }
    public void MostrarFilas(ArrayList<Caixa> Caixas, double tempoAtendimento)
    {
        System.out.println("");
        System.out.println("");
        CalcularTempo(Caixas, tempoAtendimento);
        System.out.println("");
        System.out.println("");
        System.out.println("----------------------------");
        for(int i=0; i<Caixas.size(); i++)
        {
            System.out.println("CAIXA: "+Caixas.get(i).getIdentificador());
            System.out.println("CLIENTES NA FILA: "+Caixas.get(i).getClientes().size()); 
            if(Caixas.get(i).getClientes().isEmpty())
            {
                System.out.println("TEMPO RESTANTE PARA ATENDER CLIENTE TOPO: 0");
            }
            else
            {
                
                System.out.println("TEMPO RESTANTE PARA ATENDER CLIENTE TOPO: "+Caixas.get(i).getClientes().get(0).getTempoRestante());
            }
            
            
            System.out.println("CLIENTES ATENDIDOS: "+Caixas.get(i).getnClientesAtendidos());
            System.out.println("TEMPO TOTAL ATENDIMENTO: "+Caixas.get(i).getTempoTotalAtendimento());
            System.out.print("TEMPO MEDIO DE ATENDIMENTO: "+Caixas.get(i).getTempoMedioAtendimento());
            for(int j=0; j<Caixas.get(i).getClientes().size(); j++)
            {
                System.out.print(" \t <-----CLIENTE: "+Caixas.get(i).getClientes().get(j).getIdentificador()+" NUMERO DE PRODUCTOS: "+Caixas.get(i).getClientes().get(j).getnProdutos());
                
            }
            System.out.println("");
            System.out.println("");
        }
        System.out.println("----------------------------");
        System.out.println("");
        System.out.println("");
    }
    

    public void addCaixas(ArrayList<Caixa> Caixas, ArrayList<Cliente> Clientes, int numeroC)
    {
        System.out.println("");
        System.out.println("");
        int nCaixas = 0;
        if(Caixas.isEmpty())
        {
            for(int i=1; i<=numeroC; i++)
             {
                 Caixas.add(new Caixa(this.ids, 0, 0, 0, 0, Clientes));
                 this.ids+=1;
             }
            
            System.out.println("CAIXAS ADICIONADOS COM SUCESSO!!");
        }
        else
        {
            for(int i=0; i<Caixas.size(); i++)
            {
                nCaixas++;
            }
        
        
            nCaixas= nCaixas + 1;
            Caixas.add(new Caixa(this.ids, 0, 0, 0, 0, Clientes));
            System.out.println("CAIXA ADICIONADO COM SUCESSO!!");
            this.ids+=1;
        }
        
        
        System.out.println("");
        System.out.println("");
    }
    
    public void CalcularTempo(ArrayList<Caixa> Caixas, double tempoAtendimento)
    {
        System.out.println("");
        System.out.println("");
        double tempoTotalAtendimento=0;
        for(int i=0; i<Caixas.size(); i++)
        {
            for(int j=0; j<Caixas.get(i).getClientes().size(); j++)
            {
                //System.out.println("ID: "+Caixas.get(i).getIdentificador()+ " Controlador"+Caixas.get(i).getClientes().get(j).getControlador());
                   if(Caixas.get(i).getClientes().get(j).getControlador()==0)
                   {
                       //System.out.println("ENTREI------------  ");
                    tempoTotalAtendimento= tempoTotalAtendimento + (Caixas.get(i).getClientes().get(j).getnProdutos() * tempoAtendimento);
                   }
                   else
                   {
                       tempoTotalAtendimento= tempoTotalAtendimento + Caixas.get(i).getClientes().get(j).getTempoRestante();
                   }
                    

                
            }
            Caixas.get(i).setTempoTotalAtendimento(tempoTotalAtendimento);
            Caixas.get(i).setTempoMedioAtendimento(tempoTotalAtendimento / Caixas.get(i).getClientes().size());
            tempoTotalAtendimento=0;
        }
        System.out.println("");
        System.out.println("");
    }
    
    public void RetirarCaixas(ArrayList<Caixa> Caixas)
    {
        System.out.println("");
        System.out.println("");
        for(int i=0; i<Caixas.size(); i++)
        {
            if(Caixas.get(i).getClientes().isEmpty())
            {
                Caixas.remove(Caixas.get(i));
                System.out.println("CAIXAS RETIRADOS COM SUCESSO!!");
            }
            
        }
        System.out.println("");
        System.out.println("");
    }
    
    public void AtenderClientes(ArrayList<Caixa> Caixas, int X, int AtenderX)
    {
        System.out.println("");
        System.out.println("");
        int qtdClientes=0;
        double T;
        if(AtenderX==1)
        {
           System.out.print("DIGITE O TEMPO DE ATENDIMENTO: ");
           T = ler.nextDouble();
             
        }
        else
        {
            T= X;
        }
        double Tauxiliar=T;
        double tempoParaAtender=0;
        double tempoTotalAtendimento=0;
        int contador=0;
        for(int i=0; i<Caixas.size(); i++)
        {
                if(!Caixas.get(i).getClientes().isEmpty())
                {
                    Tauxiliar=T;
                 if(T< Caixas.get(i).getClientes().get(0).getTempoRestante())
                        {
                            tempoParaAtender= Caixas.get(i).getClientes().get(0).getTempoRestante() - T;
                            //System.out.println("TEMPO T:"+T);
                            Caixas.get(i).getClientes().get(0).setTempoRestante(tempoParaAtender);
                            
                        }
                        else
                        {
                            if(T==Caixas.get(i).getClientes().get(0).getTempoRestante())
                            {
                                Caixas.get(i).getClientes().remove(Caixas.get(i).getClientes().get(0));
                                Caixas.get(i).setnClientesAtendidos(contador+1);
                                
                            }
                            else
                            {
                                int j=0;
                                while(j<Caixas.get(i).getClientes().size())
                                {
                                    if(Tauxiliar>0)
                                    {
                                        if(Tauxiliar>Caixas.get(i).getClientes().get(j).getTempoRestante())
                                        {
                                            Tauxiliar= Tauxiliar- Caixas.get(i).getClientes().get(j).getTempoRestante();
                                            //System.out.println("TEMPO AUXILIAR: "+Tauxiliar);
                                            Caixas.get(i).getClientes().remove(Caixas.get(i).getClientes().get(j));
                                            Caixas.get(i).setnClientesAtendidos(contador+1);
                                            j=0;
                                        }
                                        else
                                        {
                                            if(Tauxiliar==Caixas.get(i).getClientes().get(j).getTempoRestante())
                                            {
                                                Tauxiliar=0;
                                                Caixas.get(i).getClientes().remove(Caixas.get(i).getClientes().get(j));
                                                Caixas.get(i).setnClientesAtendidos(contador+1);
                                                j=0;
                                            }
                                            else
                                            {
                                                //System.out.println("ENTREI---->");
                                                tempoParaAtender= Caixas.get(i).getClientes().get(j).getTempoRestante() - Tauxiliar;
                                                //System.out.println(tempoParaAtender);
                                                //System.out.println("TEMPO AUXILIAR: "+Tauxiliar);
                                                Caixas.get(i).getClientes().get(j).setTempoRestante(tempoParaAtender);
                                                j++;
                                            }
                                        }   
                                    }  
                                }   
                            }
                        }
                }
        }
        
        for(int i=0; i<Caixas.size(); i++)
                    {
                        for(int j=0; j<Caixas.get(i).getClientes().size(); j++)
                        {
                            Caixas.get(i).getClientes().get(j).setIdentificador(j+1);
                            Caixas.get(i).getClientes().get(j).setControlador(1);
                            tempoTotalAtendimento= tempoTotalAtendimento + Caixas.get(i).getClientes().get(j).getTempoRestante();
                        }
                        Caixas.get(i).setTempoTotalAtendimento(tempoTotalAtendimento);
                        Caixas.get(i).setTempoMedioAtendimento(tempoTotalAtendimento / Caixas.get(i).getClientes().size());
                        tempoTotalAtendimento=0;
                    }
        System.out.println("CLIENTES ATENDIDOS COM SUCESSO!!");
        System.out.println("");
        System.out.println("");
    }
    
    public void Juntar(ArrayList<Caixa> Caixas, ArrayList<Cliente> Clientes, double tempoAtendimento)
    {
        Caixa caixa= new Caixa();
        for(int k=0; k<Clientes.size(); k++)
        {
                        //System.out.println("");
                   // System.out.println("");
                    
                    int id = 0, nClientes=100000, j;




                            for(int i=0; i<Caixas.size(); i++)
                                            { 
                                                //System.out.println(nClientes);
                                                //System.out.println(Caixas.get(i).getClientes().size());
                                                if(nClientes>Caixas.get(i).getClientes().size())
                                                {

                                                    nClientes=Caixas.get(i).getClientes().size();
                                                    id=Caixas.get(i).getIdentificador();

                                                }
                                            }
                                             this.Clientes= new ArrayList();
                                             for(int i=0; i<Caixas.size(); i++)
                                            {
                                                if(nClientes==Caixas.get(i).getClientes().size() && id==Caixas.get(i).getIdentificador())
                                                {

                                                    for(j=0; j<Caixas.get(i).getClientes().size(); j++)
                                                    {
                                                        
                                                        this.Clientes.add(Caixas.get(i).getClientes().get(j));
                                                        
                                                    }
                                                    this.Clientes.add(new Cliente(Clientes.get(k).getnProdutos() * tempoAtendimento,j+ 1, Clientes.get(k).getnProdutos()));
                                                    //caixa= new Caixa(Caixas.get(i).getIdentificador(), (Caixas.get(i).getnClientesFila() +1), Caixas.get(i).getnClientesAtendidos(), Caixas.get(i).getTempoTotalAtendimento(), Caixas.get(i).getTempoMedioAtendimento(), Clientes);
                                                    Caixas.get(i).setClientes(this.Clientes);

                                                    break;
                                                }
                                            }
                                            
                                            
                                    System.out.println("");
                                    System.out.println("");
        }
        Clientes.clear();
        
    }
}
