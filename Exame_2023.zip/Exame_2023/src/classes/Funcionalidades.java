/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author santi
 */
public class Funcionalidades {
    Scanner ler= new Scanner(System.in);
    public static ArrayList<Caixa> Caixas = new ArrayList();
    public static ArrayList<Cliente> Clientes = new ArrayList();
    public static ArrayList<Cliente> c = new ArrayList();
    public static Caixa caixa= new Caixa();
    public static Cliente cliente= new Cliente();
    public static Ficheiro ficheiro= new Ficheiro();
    public  int nCaixas;
    public String aux;
    double tempoAtendimento;
    int X, opcao, controlador=0, opFile=0, AtenderX=0, Recuperar;
    String str;
    public Funcionalidades() throws IOException
    {
        Scanner ler= new Scanner(System.in);
        opcao = 0;
        
        ficheiro.lerFich(Caixas, Clientes);
        Clientes= new ArrayList();
        
        System.out.println("");
        System.out.println("");
        System.out.println("------MENU-------");
        do
        {
            
            
            System.out.println("");
            System.out.println("");
            System.out.println("1-MANUAL:");
            System.out.println("2-AUTOMATICO:");
            System.out.println("3-MOSTRAR DADOS RECUPERADOS DO FICHEIRO:");
            System.out.println("4-SAIR:");
            System.out.print("DIGITE A OPCAO DE DESEJA: ");
            try {
                opcao = ler.nextInt();
            } catch (Exception e) {
                System.out.println("VALOR INVALIDO !!");
                return;
            }
            switch(opcao)
            {
                case 1:
                {
                    Manual();
                    break;
                }
                case 2:
                {
                    Automatico();
                    break;
                }
                
                case 3:
                {
                    System.out.println("");
                    System.out.println("");
                    caixa.MostrarFilas(Caixas, tempoAtendimento);
                    break;
                }
                case 4:
                {
                    ficheiro.escreveFich(Caixas, Clientes);
                    System.out.println("");
                    System.out.println("");
                    System.out.println("DADOS GUARDADOS NO FICHEIRO COM SUCESSO!!");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("OBRIGADO POR TESTAR O PROGRAMA :)");
                    break;
                }
                
                  
            }
        }while(opcao!=4); 
    }
    
    public void Manual() throws IOException
    {
        AtenderX=1;
        System.out.print("DIGITE O TEMPO DE ATENDIMENTO DE UM PRODUCTO: ");
        
        aux = ler.nextLine();
        if(aux == null||aux.isEmpty())
            tempoAtendimento = 5;
        else
            tempoAtendimento = Double.valueOf(aux).doubleValue();
        
        if(!Caixas.isEmpty())
        {
            
            System.out.print("DIGITE 1 PARA RECUPERAR OS DADOS QUARDADOS NO FICHEIRO E 2 PARA CRIAR NOVOS DADOS: ");
            Recuperar= ler.nextInt();
        }
        if(Recuperar==1)
        {
            
        }
        else
        {
            Caixas.clear();
            Clientes.clear();
            ler.nextLine();
            System.out.print("DIGITE O NUMERO DE CAIXAS: ");
            nCaixas= ValidaCaixa();
            
        }
            
        int op;
        System.out.println("(MODO MANUAL)");
        System.out.println("------MENU-------");
        do
        {
            if(!Caixas.isEmpty() && !Clientes.isEmpty())
                        {
                            caixa.Juntar(Caixas, Clientes, tempoAtendimento);
                            
                        }
            System.out.println("");
            System.out.println("");
            System.out.println("1-MOSTRARAR FILAS DAS CAIXAS;");
            System.out.println("2-CRIAR CLIENTES;");
            System.out.println("3-ADICIONAR CAIXAS;");
            System.out.println("4-RETIRAR CAIXAS DE ATENDIMENTO;");
            System.out.println("5-ATENDER T TEMPO;");
            System.out.println("6-SAIR;");
            
            System.out.print("DIGITE A OPCAO DE DESEJA: ");
            try {
                op = ler.nextInt();
            } catch (Exception e) {
                System.out.println("VALOR INVALIDO !!");
                return;
            }
            
            switch(op)
            {
                case 1:
                {
                    if(Caixas.isEmpty())
                    {
                        System.out.println("AINDA NÃO EXISTEM CAIXAS DISPONIVÉIS.");
                    }
                    else
                    {
                        
                        
                      caixa.MostrarFilas(Caixas, tempoAtendimento);
                    }
                    
                    break;
                }
                case 2:
                {
                    cliente.addCliente(Clientes);
                   
                    break;
                }
                case 3:
                {
                    
                    caixa.addCaixas(Caixas, c, nCaixas);
                    
                    break;
                }
                case 4:
                {
                    caixa.RetirarCaixas(Caixas);
                    break;
                }
                case 5:
                {
                     if(!Caixas.isEmpty())
                        {
                            
                            caixa.AtenderClientes(Caixas, X, AtenderX);
                        }
                     else
                     {
                         System.out.println("NÃO EXISTEM CLIENTES OU CAIXAS CRIADOS!!");
                     }
                    
                    break;
                }
                case 6:
                {
                    
                    break;
                }
            }
        }while(op!=6);
    }
    
    public void Automatico() throws IOException
    { 
        AtenderX=2;
        String str;
        System.out.println("(MODO AUTOMATICO)");
        ler.nextLine();
            System.out.print("DIGITE O TEMPO DE ATENDIMENTO DE UM PRODUCTO: ");
            aux = ler.nextLine();
            if(aux == null||aux.isEmpty())
                tempoAtendimento = 5;
            else
                tempoAtendimento = Double.valueOf(aux).doubleValue();
            
                if(!Caixas.isEmpty())
            {

                System.out.println("DIGITE 1 PARA RECUPERAR OS DADOS QUARDADOS NO FICHEIRO E 2 PARA CRIAR NOVOS DADOS: ");
                Recuperar= ler.nextInt();
                
            }
            if(Recuperar==1)
            {

            }
            else
            {
                Caixas.clear();
                Clientes.clear();
                ler.nextLine();
                System.out.print("DIGITE O NUMERO DE CAIXAS: ");
                nCaixas= ValidaCaixa();
                caixa.addCaixas(Caixas, c, nCaixas);
            }
            
            ler.nextLine();
            System.out.print("DIGITE O INTERVALO DE TEMPO MAXIMO ENTRE CLIENTES: ");
            aux=ler.nextLine();
            double intervalo;
            if(aux == null||aux.isEmpty())
                intervalo = 15;
            else
                intervalo = Double.valueOf(aux).doubleValue();
            
        do
        {
            System.out.println("");
            System.out.println("");
            System.out.println("1-A MOSTRAR FILAS DAS CAIXAS: ");
          
            X= getRandomNumber(1, (int) intervalo);
            System.out.println("O NUMERO ALEATORIO ENTRE 1 E "+intervalo+" E "+X);
            System.out.println("2-A CRIAR CLIENTES: ");
            cliente.addCliente(Clientes);
            caixa.Juntar(Caixas, Clientes, tempoAtendimento);

            System.out.println("2-A ATENDER CLIENTES: ");
            caixa.AtenderClientes(Caixas, X,AtenderX);
            System.out.println("1-A MOSTRAR FILAS DAS CAIXAS: ");
            caixa.MostrarFilas(Caixas,tempoAtendimento);
                System.out.println("");
                System.out.println("");
                System.out.print("Digite C para continuar e fim para parar a execução:");
                str=ler.nextLine();
        }while(!str.equalsIgnoreCase("fim"));
        
    }
    
    static int getRandomNumber(int min, int max){
        return (int) ((Math.random() * (max - min)) + min);
    }
    
    public void addCaixasA(ArrayList<Caixa> Caixas, ArrayList<Cliente> Clientes, int numeroC)
    {
        
        for(int i=1; i<=numeroC; i++)
             {
                 Caixas.add(new Caixa(i, 0, 0, 0, 0, Clientes));
             }
            
            System.out.println("CAIXAS ADICIONADOS COM SUCESSO!!");
    }
    
    public int ValidaCaixa()
    {
        aux = ler.nextLine();
        if(aux == null || aux.isEmpty())
            nCaixas = 4;
        else
            nCaixas= Integer.parseInt(aux);

        if(nCaixas>0)
        {
            
        }
        else
        {
            if(nCaixas<0)
            {
                System.out.print("DIGITE NOVAMENTE O TEMPO DE ATENDIMENTO DE UM PRODUCTO: ");
                ValidaCaixa();
            }
            else
            {
                nCaixas=4;
            }
        }
        
        return(nCaixas);
    }
   
}
