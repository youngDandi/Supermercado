/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
/**
 *
 * @author santi
 */
public class Ficheiro {
    Scanner ler = new Scanner(System.in);
    private Caixa caixa;
    private Cliente cliente;
    
    public Ficheiro() {

    }
    
    public void escreveFich(ArrayList Caixas, ArrayList Clientes) throws IOException
    {
        BufferedWriter esc = new BufferedWriter(new FileWriter("ficheiro.txt"));
        cliente= new Cliente();
        caixa= new Caixa();
        try
        {
            esc.write("Caixas "+Caixas.size());
            esc.newLine();
            if(! Caixas.isEmpty())
            {
                
                
                
                for(int i=0; i<Caixas.size(); i++)
                {
                    Caixa c= (Caixa) Caixas.get(i);
                    
                    

                    String aux= Integer.toString(c.getIdentificador());  
                    esc.write(aux);
                    esc.newLine();
                    aux=Integer.toString(c.getClientes().size());
                    esc.write(aux);
                    esc.newLine();
                    aux=Integer.toString(c.getnClientesAtendidos());
                    esc.write(aux);
                    esc.newLine();
                    aux = Double.toString(c.getTempoTotalAtendimento());
                    esc.write(aux);
                    esc.newLine();
                    aux = Double.toString(c.getTempoMedioAtendimento());
                    esc.write(aux);
                    esc.newLine();
                    if(c.getClientes().isEmpty())
                    {
                        
                        esc.newLine();
                    }
                    else
                    {
                       esc.write("Clientes "+c.getClientes().size());
                       esc.newLine();
                        for(int j=0; j<c.getClientes().size(); j++)
                        {
                            aux= Integer.toString(c.getClientes().get(j).getIdentificador());
                            esc.write(aux);
                            esc.newLine();
                            aux= Integer.toString(c.getClientes().get(j).getnProdutos());
                            esc.write(aux);
                            esc.newLine();
                            aux = Double.toString(c.getClientes().get(j).getTempoRestante());
                            esc.write(aux);
                            esc.newLine();
                            aux = Integer.toString(c.getClientes().get(j).getControlador());
                            esc.write(aux);
                            esc.newLine();
                        }
                    }
                    
                }
            }
            else
            {
                if(!Clientes.isEmpty())
                    {
                        esc.write("Clientes "+Clientes.size());
                        esc.newLine();
                        for(int j=0; j<Clientes.size(); j++)
                        {
                            cliente= (Cliente) Clientes.get(j);
                            String aux= Integer.toString(cliente.getIdentificador());
                            esc.write(aux);
                            esc.newLine();
                            aux= Integer.toString(cliente.getnProdutos());
                            esc.write(aux);
                        }
                    }
            }
            esc.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void lerFich(ArrayList  Caixas, ArrayList  Clientes)
    {
        Caixa c;
        Cliente cli;
        BufferedReader f = null;
        try{
            f = new BufferedReader (new FileReader("ficheiro.txt"));
        }catch (Exception m){
            System.out.println(m.getMessage());
        }
        
        try{
            
            int id, nClientesFila, nClientesAtendidos, qtd, idc, nProdutos, controlador;
            double tempoRestante, tempoTotalAtendimento,tempoMedioAtendimento;
            String st = f.readLine();
            String s[] = st.split(" ");
            
                qtd=Integer.parseInt(s[1].trim());
                //System.out.print(qtd);
                for(int i=0; i<qtd; i++)
                {
                        st = pulo(st,f);
                        id = Integer.parseInt(st.trim());
                        st = pulo(st,f);
                        //System.out.print(id);
                        nClientesFila= Integer.parseInt(st.trim());
                        //System.out.print(nClientesFila);
                        st = pulo(st,f);
                        nClientesAtendidos= Integer.parseInt(st.trim());
                        //System.out.print(nClientesAtendidos);
                        st = pulo(st,f);
                        tempoTotalAtendimento=Double.valueOf(st).doubleValue();
                        //System.out.print(tempoTotalAtendimento);
                        st = pulo(st,f);
                        tempoMedioAtendimento=Double.valueOf(st).doubleValue();
                       // System.out.print(tempoMedioAtendimento);
                        st = pulo(st,f);
                        String s1[] = st.split(" ");
                        int nClientes= Integer.parseInt(s1[1].trim());
                        //System.out.print(nClientes);
                        for(int j=0; j<nClientes; j++)
                        {
                            st = pulo(st,f);
                            idc= Integer.parseInt(st.trim());
                            //System.out.print(idc);
                            st = pulo(st,f);
                            nProdutos= Integer.parseInt(st.trim());
                            //System.out.println(nProdutos);
                            st = pulo(st,f);
                            tempoRestante= Double.valueOf(st).doubleValue();
                            //System.out.println(tempoRestante);
                            st = pulo(st,f);
                            controlador=Integer.parseInt(st.trim());
                            //System.out.println(controlador);
                            cli= new Cliente(tempoRestante, idc, nProdutos, controlador);
                            Clientes.add(cli); 
                            
                        }
                        c= new Caixa(id, nClientesFila,nClientesAtendidos, tempoTotalAtendimento, tempoMedioAtendimento, Clientes);
                        Caixas.add(c);
                        Clientes= new ArrayList();
            }
                 
            f.close();
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public static String pulo(String st,BufferedReader f) throws IOException {
        st = f.readLine();
        return st;
    }
    public static String duplopulo(String st,BufferedReader f) throws IOException {
        st = f.readLine();
        st = f.readLine();
        return st;
    }
}
