/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.ArrayList;

/**
 *
 * @author santi
 */
public class Cliente {
    private int Identificador;
    private int nProdutos;
    private double tempoRestante;
    private int controlador=0;

    public int getControlador() {
        return controlador;
    }

    public void setControlador(int controlador) {
        this.controlador = controlador;
    }
    
    
    public double getTempoRestante() {
        return tempoRestante;
    }

    public void setTempoRestante(double tempoRestante) {
        this.tempoRestante = tempoRestante;
    }
    
    
    
   
    
    
    
    public int getIdentificador() {
        return Identificador;
    }

    public void setIdentificador(int Identificador) {
        this.Identificador = Identificador;
    }

    public int getnProdutos() {
        return nProdutos;
    }

    public void setnProdutos(int nProdutos) {
        this.nProdutos = nProdutos;
    }

    public Cliente(double tempoRestante,int Identificador, int nProdutos) {
        this.Identificador = Identificador;
        this.nProdutos = nProdutos;
        this.tempoRestante = tempoRestante;
        
    }
    public Cliente(double tempoRestante,int Identificador, int nProdutos, int controlador) {
        this.Identificador = Identificador;
        this.nProdutos = nProdutos;
        this.tempoRestante = tempoRestante;
        this.controlador = controlador;
    }
    public Cliente(int Identificador, int nProdutos , int controlador) {
        this.Identificador = Identificador;
        this.nProdutos = nProdutos;
        this.controlador = controlador;
    }
    
    public Cliente() {
        
        
    }
    
    public void addCliente(ArrayList<Cliente> Clientes)
    {
        System.out.println("");
        System.out.println("");
        int nProdutos= getRandomNumber(2, 121);
        Clientes.add(new Cliente(0,nProdutos,0));
        System.out.println("CLIENTE ADICIONADO COM SUCESSO!!");
        System.out.println("");
        System.out.println("");
        
        /*for(int k=0; k<Clientes.size(); k++)
        {
            //System.out.println("---------------");
            System.out.println(Clientes.get(k).getnProdutos());
        }
        */
    }
    
    static int getRandomNumber(int min, int max){
        return (int) ((Math.random() * (max - min)) + min);
    }
}
